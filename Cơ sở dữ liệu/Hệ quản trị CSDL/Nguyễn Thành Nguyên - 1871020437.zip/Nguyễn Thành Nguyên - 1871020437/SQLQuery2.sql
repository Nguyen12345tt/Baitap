﻿-- VD 2
-- Nguyễn Thành Nguyên - 1871020437
-- Tính giá trị a + b
-- B1: Khai báo biến kiểu dữ liệu int
-- B2: Đặt giá trị cho biến, tính toán tổng
-- B3: In ra kết quả
declare @a int
declare @b int
declare @tong int
set @a = 10
set @b = 11
set @tong= @a + @b 
print @tong