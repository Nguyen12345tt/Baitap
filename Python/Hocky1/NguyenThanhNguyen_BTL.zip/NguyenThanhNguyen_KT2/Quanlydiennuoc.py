import json
import os   

# --- Các hàm tính toán cơ bản ---
def tinh_so_tieu_thu(chi_so_dau, chi_so_cuoi):
    return chi_so_cuoi - chi_so_dau

def tinh_tien_dien(so_tieu_thu):
    # Đây là bảng giá điện bậc thang ví dụ (có thể thay đổi theo quy định thực tế)
    if so_tieu_thu <= 50:
        return so_tieu_thu * 1728
    elif 50 < so_tieu_thu <= 100:
        return 50 * 1728 + (so_tieu_thu - 50) * 2074
    elif so_tieu_thu <= 200:
        return 50 * 1728 + 50 * 2074 + (so_tieu_thu - 100) * 2503
    elif so_tieu_thu <= 300:
        return 50 * 1728 + 50 * 2074 + 100 * 2503 + (so_tieu_thu - 200) * 2587
    elif so_tieu_thu <= 400:
        return 50 * 1728 + 50 * 2074 + 100 * 2503 + 100 * 2587 + (so_tieu_thu - 300) * 2834
    else: # Nếu tiêu thụ trên 400 kWh
        return 50 * 1728 + 50 * 2074 + 100 * 2503 + 100 * 2587 + 100 * 2834 + (so_tieu_thu - 400) * 2927

def tinh_tien_nuoc(so_tieu_thu):
    if so_tieu_thu <= 10:
        return so_tieu_thu * 5973
    elif so_tieu_thu <= 20:
        return 10 * 5973 + (so_tieu_thu - 10) * 7052
    else: # Nếu tiêu thụ trên 20 m³
        return 10 * 5973 + 10 * 7052 + (so_tieu_thu - 20) * 8699

# --- Hàm hỗ trợ hiển thị danh sách hóa đơn ---
def hien_thi_danh_sach_hoa_don(danh_sach):
    if not danh_sach:
        print("Danh sách hóa đơn rỗng.")
        return
    for i, hd in enumerate(danh_sach):
        print(f"--- Hóa đơn số {i+1} ---")
        for key, value in hd.items(): 
            display_key = key.replace('_', ' ').title()
            if 'tien' in key or 'tong' in key:
                print(f"{display_key}: {value:,} VNĐ")
            elif 'thanh_toan' in key:
                print(f"{display_key}: {'Đã thanh toán' if value else 'Chưa thanh toán'}")
            else: 
                print(f"{display_key}: {value}")

def hien_thi_thong_tin_thanh_toan(data):
    print("\n--- Thông Tin Thanh Toán ---")
    if not data:
        print("Không có hóa đơn nào để hiển thị thông tin thanh toán.")
        return
    for i, hd in enumerate(data): 
        print(f"\n--- Hóa đơn số {i+1} ---")
        print(f"Năm: {hd['nam']}, Tháng: {hd['thang']}, Khách hàng: {hd['ten_khach_hang']}")
        print(f"    Tổng tiền phải thanh toán: {hd['tong_tien']:,} VNĐ")
        if 'da_thanh_toan' in hd:
            trang_thai = "Đã thanh toán" if hd['da_thanh_toan'] else "Chưa thanh toán"
            print(f"    Trạng thái: {trang_thai}")
        else:
            print("    Trạng thái: Không xác định (chưa cập nhật trường 'da_thanh_toan')")
        print("    (Chức năng này có thể được mở rộng để thêm hạn thanh toán và phương thức thanh toán)")

# --- Các chức năng chính ---
def them_hoa_don(data):
    print("\n--- Thêm Hóa Đơn ---")
    try:
        nam = int(input("Năm: "))
        thang = int(input("Tháng: "))
        if not (1 <= thang <= 12):
            print("Lỗi: Tháng phải là số nguyên từ 1 đến 12.")
            return
        if nam <= 0:
            print("Lỗi: Năm phải là số dương.")
            return
    except ValueError:
        print("Lỗi: Năm và Tháng phải là số nguyên. Vui lòng thử lại.")
        return

    ten_khach_hang = input("Tên khách hàng: ")
    if not ten_khach_hang.strip():
        print("Lỗi: Tên khách hàng không được để trống.")
        return

    try:
        chi_so_dau_dien = int(input("Chỉ số công tơ điện đầu: "))
        chi_so_cuoi_dien = int(input("Chỉ số công tơ điện cuối: "))
        if chi_so_dau_dien < 0 or chi_so_cuoi_dien < 0:
            print("Lỗi: Chỉ số công tơ không thể là số âm.")
            return
        if chi_so_dau_dien > chi_so_cuoi_dien:
            print("Lỗi: Chỉ số cuối điện không thể nhỏ hơn chỉ số đầu điện.")
            return
    except ValueError:
        print("Lỗi: Chỉ số công tơ điện phải là số nguyên. Vui lòng thử lại.")
        return

    try:
        chi_so_dau_nuoc = int(input("Chỉ số công tơ nước đầu: "))
        chi_so_cuoi_nuoc = int(input("Chỉ số công tơ nước cuối: "))
        if chi_so_dau_nuoc < 0 or chi_so_cuoi_nuoc < 0:
            print("Lỗi: Chỉ số công tơ không thể là số âm.")
            return
        if chi_so_dau_nuoc > chi_so_cuoi_nuoc:
            print("Lỗi: Chỉ số cuối nước không thể nhỏ hơn chỉ số đầu nước.")
            return
    except ValueError:
        print("Lỗi: Chỉ số công tơ nước phải là số nguyên. Vui lòng thử lại.")
        return

    so_kw_dien = tinh_so_tieu_thu(chi_so_dau_dien, chi_so_cuoi_dien)
    so_m3_nuoc = tinh_so_tieu_thu(chi_so_dau_nuoc, chi_so_cuoi_nuoc)
    tien_dien = tinh_tien_dien(so_kw_dien)
    tien_nuoc = tinh_tien_nuoc(so_m3_nuoc)

    # Tạo một từ điển mới chứa thông tin hóa đơn
    hoa_don_moi = {
        "nam": nam,
        "thang": thang,
        "ten_khach_hang": ten_khach_hang,
        "chi_so_dau_dien": chi_so_dau_dien,
        "chi_so_cuoi_dien": chi_so_cuoi_dien,
        "so_kw_dien": so_kw_dien,
        "tien_dien": tien_dien,
        "chi_so_dau_nuoc": chi_so_dau_nuoc,
        "chi_so_cuoi_nuoc": chi_so_cuoi_nuoc,
        "so_m3_nuoc": so_m3_nuoc,
        "tien_nuoc": tien_nuoc,
        "tong_tien": tien_dien + tien_nuoc,
        "da_thanh_toan": False # Mặc định là chưa thanh toán khi mới thêm
    }
    data.append(hoa_don_moi) # Thêm hóa đơn mới vào danh sách dữ liệu
    print("Hóa đơn đã được thêm (chỉ lưu trong phiên làm việc này).")

def hien_thi_thong_tin_tieu_thu_va_chi_phi(data):
    print("\n--- Thông Tin Tiêu Thụ và Chi Phí ---")
    if not data: 
        print("Không có hóa đơn nào để hiển thị thông tin.")
        return
    for i, hd in enumerate(data): # Duyệt qua từng hóa đơn
        print(f"\n--- Hóa đơn số {i+1} ---")
        print(f"Năm: {hd['nam']}, Tháng: {hd['thang']}, Khách hàng: {hd['ten_khach_hang']}")
        print(f"    Điện:")
        print(f"      Chỉ số đầu: {hd['chi_so_dau_dien']}, Chỉ số cuối: {hd['chi_so_cuoi_dien']}")
        print(f"      Số kWh tiêu thụ: {hd['so_kw_dien']}, Thành tiền: {hd['tien_dien']:,} VNĐ")
        print(f"    Nước:")
        print(f"      Chỉ số đầu: {hd['chi_so_dau_nuoc']}, Chỉ số cuối: {hd['chi_so_cuoi_nuoc']}")
        print(f"      Số m³ tiêu thụ: {hd['so_m3_nuoc']}, Thành tiền: {hd['tien_nuoc']:,} VNĐ")
        print(f"    Tổng tiền: {hd['tong_tien']:,} VNĐ")
        # Thêm hiển thị trạng thái thanh toán nếu có trường này trong hóa đơn
        if 'da_thanh_toan' in hd:
            print(f"    Trạng thái thanh toán: {'Đã thanh toán' if hd['da_thanh_toan'] else 'Chưa thanh toán'}")

def xoa_hoa_don(data):
    print("\n--- Xóa Hóa Đơn ---")
    if not data: # Kiểm tra nếu danh sách rỗng
        print("Không có hóa đơn để xóa.")
        return
    hien_thi_danh_sach_hoa_don(data)
    try:
        idx = int(input("Nhập số hóa đơn muốn xóa (ví dụ 1, 2, ...): ")) - 1
        if not (0 <= idx < len(data)):
            print("Số hóa đơn không hợp lệ.")
            return
        deleted_hd = data.pop(idx)
        print(f"Đã xóa hóa đơn số {idx+1} của khách hàng {deleted_hd['ten_khach_hang']}.")
    except ValueError:
        print("Đầu vào không hợp lệ. Vui lòng nhập một số.")

def luu_du_lieu(data, filename="hoa_don.json"):
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        print(f"Dữ liệu đã được lưu vào file '{filename}'.")
    except Exception as e:
        print(f"Lỗi khi lưu dữ liệu: {e}")

def tai_du_lieu(filename="hoa_don.json"):
    if os.path.exists(filename):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            print(f"Dữ liệu đã được tải từ file '{filename}'.")
            return data
        except json.JSONDecodeError:
            print(f"Lỗi: File '{filename}' không phải là định dạng JSON hợp lệ. Bắt đầu với dữ liệu trống.")
            return []
        except Exception as e:
            print(f"Lỗi khi tải dữ liệu: {e}")
            return []
    else:
        print(f"File '{filename}' không tồn tại. Bắt đầu với dữ liệu trống.")
        return []

def tim_hoa_don_dien_cao_nhat(data):
    print("\n--- Hóa Đơn Tiền Điện Cao Nhất ---")
    if not data:
        print("Không có hóa đơn để tìm kiếm.")
        return
    max_hd = None 
    for hd in data:
        if max_hd is None or hd['tien_dien'] > max_hd['tien_dien']:
            max_hd = hd
    if max_hd:
        hien_thi_danh_sach_hoa_don([max_hd])
    else:
        print("Không tìm thấy hóa đơn tiền điện cao nhất.")

def hien_thi_lich_su_tieu_thu(data):
    print("\n--- Lịch Sử Tiêu Thụ (Đơn Giản) ---")
    if not data: # Kiểm tra nếu danh sách rỗng
        print("Không có hóa đơn nào để hiển thị lịch sử tiêu thụ.")
        return
    lich_su = {}
    for hd in data:
        ten = hd['ten_khach_hang']
        if ten not in lich_su:
            lich_su[ten] = [] 
        lich_su[ten].append({
            "nam": hd['nam'],
            "thang": hd['thang'],
            "kw_dien": hd['so_kw_dien'],
            "m3_nuoc": hd['so_m3_nuoc']
        })

    for ten, ds_ky in lich_su.items():
        print(f"\n--- Lịch sử tiêu thụ của khách hàng: {ten} ---")
        ds_ky.sort(key=lambda x: (x['nam'], x['thang']))
        for ky in ds_ky:
            print(f"    Năm {ky['nam']}, Tháng {ky['thang']}: Điện = {ky['kw_dien']} kWh, Nước = {ky['m3_nuoc']} m³")

def tim_hoa_don_nuoc_cao_nhat(data):
    print("\n--- Hóa Đơn Tiền Nước Cao Nhất ---")
    if not data:
        print("Không có hóa đơn để tìm kiếm.")
        return
    max_hd = None
    for hd in data:
        if max_hd is None or hd['tien_nuoc'] > max_hd['tien_nuoc']:
            max_hd = hd
    if max_hd:
        hien_thi_danh_sach_hoa_don([max_hd])
    else:
        print("Không tìm thấy hóa đơn tiền nước cao nhất.")

def xuat_bao_cao_chi_tiet(data, filename="bao_cao_hoa_don.txt"):
    print("\n--- Xuất Báo Cáo Chi Tiết ---")
    if not data:
        print("Không có hóa đơn để xuất báo cáo.")
        return
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("BÁO CÁO CHI TIẾT HÓA ĐƠN ĐIỆN NƯỚC\n") # Ghi tiêu đề báo cáo
            f.write("=" * 40 + "\n\n") # Ghi đường kẻ phân cách
            
            for i, hd in enumerate(data): # Duyệt qua từng hóa đơn
                f.write(f"--- Hóa đơn số {i+1} ---\n") # Ghi số hóa đơn
                f.write(f"Năm: {hd['nam']}, Tháng: {hd['thang']}, Khách hàng: {hd['ten_khach_hang']}\n")
                f.write(f"    Điện:\n")
                f.write(f"      Chỉ số đầu: {hd['chi_so_dau_dien']}, Chỉ số cuối: {hd['chi_so_cuoi_dien']}\n")
                f.write(f"      Số kWh tiêu thụ: {hd['so_kw_dien']}, Thành tiền: {hd['tien_dien']:,} VNĐ\n") # Định dạng tiền
                f.write(f"    Nước:\n")
                f.write(f"      Chỉ số đầu: {hd['chi_so_dau_nuoc']}, Chỉ số cuối: {hd['chi_so_cuoi_nuoc']}\n")
                f.write(f"      Số m³ tiêu thụ: {hd['so_m3_nuoc']}, Thành tiền: {hd['tien_nuoc']:,} VNĐ\n") # Định dạng tiền
                f.write(f"    Tổng tiền: {hd['tong_tien']:,} VNĐ\n") 
                f.write(f"    Trạng thái thanh toán: {'Đã thanh toán' if hd['da_thanh_toan'] else 'Chưa thanh toán'}\n")
                f.write("-" * 20 + "\n")
            f.write("\n" + "=" * 40 + "\n")
            f.write("Kết thúc báo cáo.\n")
        print(f"Báo cáo đã được xuất ra file '{filename}'.")
    except Exception as e:
        print(f"Lỗi khi xuất báo cáo: {e}")

# --- Hàm Menu Chính ---
def main():
    data = tai_du_lieu() # Tải dữ liệu hóa đơn từ file JSON khi khởi động chương trình

    while True: # Vòng lặp vô hạn để hiển thị menu liên tục cho đến khi người dùng chọn thoát
        print("\n--- Quản Lý Hóa Đơn Điện, Nước ---")
        print("1. Thêm hóa đơn")
        print("2. Xóa hóa đơn")
        print("3. Hiển thị thông tin tiêu thụ và chi phí")
        print("4. Hiển thị thông tin thanh toán")
        print("5. Hiển thị tất cả hóa đơn chi tiết")
        print("6. Tìm hóa đơn tiền điện cao nhất")
        print("7. Tìm hóa đơn tiền nước cao nhất")
        print("8. Xuất báo cáo chi tiết ra file (.txt)")
        print("0. Lưu dữ liệu và Thoát")

        choice = input("Chọn chức năng: ") # Nhận lựa chọn từ người dùng

        try:
            choice_int = int(choice) # Chuyển đổi lựa chọn sang số nguyên
        except ValueError: # Bắt lỗi nếu người dùng nhập không phải số
            print("Lựa chọn không hợp lệ. Vui lòng nhập một số.")
            continue # Tiếp tục vòng lặp để hiển thị lại menu

        # Xử lý các lựa chọn của người dùng bằng các câu lệnh if/elif
        if choice_int == 1:
            them_hoa_don(data)
        elif choice_int == 2:
            xoa_hoa_don(data)
        elif choice_int == 5:
            hien_thi_danh_sach_hoa_don(data)
        elif choice_int == 3:
            hien_thi_thong_tin_tieu_thu_va_chi_phi(data)
        elif choice_int == 4:
            hien_thi_thong_tin_thanh_toan(data)
        elif choice_int == 6:
            tim_hoa_don_dien_cao_nhat(data)
        elif choice_int == 7:
            tim_hoa_don_nuoc_cao_nhat(data)
        elif choice_int == 8:
            xuat_bao_cao_chi_tiet(data)
        elif choice_int == 0:
            luu_du_lieu(data)
            print("Cảm ơn bạn đã sử dụng chương trình!")
            break
        else:
            print("Lựa chọn không hợp lệ. Vui lòng thử lại.")

if __name__ == "__main__":
    main()